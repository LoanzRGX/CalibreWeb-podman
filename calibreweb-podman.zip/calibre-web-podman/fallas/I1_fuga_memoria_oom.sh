#!/bin/bash
# CASO I1 - Fuga de memoria y OOM killer
# Usar dos ventanas: A (comandos) y B (podman stats calibre-web).

# 1. RAM del servidor (717 MiB, sin swap) y límite original del contenedor (512 MiB)
free -h
podman inspect calibre-web --format '{{.HostConfig.Memory}} {{.HostConfig.MemorySwap}}'

# 2. Instalar stress-ng dentro del contenedor (capa temporal)
podman exec calibre-web sh -c 'apt-get update -qq && apt-get install -y -qq stress-ng'

# 3. Bajar el límite a 256 MiB para la prueba (el servidor tiene poca RAM libre)
podman update --memory 256m --memory-swap 256m calibre-web
podman inspect calibre-web --format '{{.HostConfig.Memory}} {{.HostConfig.MemorySwap}}'

# 4. Provocar la fuga: pedir 400 MiB (más que el límite) durante 60 s
#    En la ventana B:  podman stats calibre-web   -> llega a 100 %
podman exec calibre-web stress-ng --vm 1 --vm-bytes 400M --vm-keep --timeout 60s

# 5. Evidencia del OOM killer (oom_kill > 0 y "Killed process ... (stress-ng-vm)")
podman exec calibre-web cat /sys/fs/cgroup/memory.events
sudo dmesg | grep -i killed

# 6. Solución: reiniciar el servicio crea un contenedor nuevo (vuelve 512 MiB, sin stress-ng)
systemctl --user restart calibre-web
sleep 15
podman inspect calibre-web --format '{{.HostConfig.Memory}}'
podman exec calibre-web sh -c 'command -v stress-ng || echo "stress-ng ya no existe"'
