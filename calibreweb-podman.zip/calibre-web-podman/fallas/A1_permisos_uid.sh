#!/bin/bash
# CASO A1 - Volumen con permisos rotos por el mapeo de UID (rootless)

# 1. Usuarios del host y del contenedor
id                                   # uid=1000(ec2-user)
cat /etc/subuid                      # ec2-user:100000:65536
podman exec calibre-web id abc       # uid=1000(abc)

# 2. Los mismos archivos vistos desde el host (100999) y desde el contenedor (1000)
ls -ln ~/calibre/books
podman unshare ls -ln ~/calibre/books

# 3. Provocar la falla: la carpeta pasa a ser de ec2-user (= root dentro del contenedor)
podman unshare chown -R 0:0 ~/calibre/books
ls -ln ~/calibre/books

# 4. Comprobar que no se puede escribir
#    En la web: editar metadatos -> "[Errno 13] Permission denied" y "attempt to write a readonly database"
podman exec --user 1000 calibre-web touch /books/prueba.txt; echo $?   # Permission denied, 1

# 5. Solución: devolver la carpeta al usuario 1000 del contenedor
podman unshare chown -R 1000:1000 ~/calibre/books
ls -ln ~/calibre/books               # otra vez 100999
systemctl --user restart calibre-web
sleep 15 && podman exec --user 1000 calibre-web touch /books/prueba.txt; echo $?   # 0 = OK
podman exec --user 1000 calibre-web rm /books/prueba.txt
