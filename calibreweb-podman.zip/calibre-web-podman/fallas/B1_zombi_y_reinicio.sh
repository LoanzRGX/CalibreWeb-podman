#!/bin/bash
# CASO B1 - Proceso zombi y servicio que no reinicia
# Ejecutar los comandos uno por uno y tomar captura de cada resultado.

# 1. Estado inicial (antes: NRestarts=0)
systemctl --user show calibre-web -p NRestarts

# 2. Crear 5 zombis: el shell lanza 5 hijos y se convierte en "sleep 600", que nunca los espera
podman exec -d calibre-web sh -c 'for i in 1 2 3 4 5; do sleep 1 & done; exec sleep 600'
sleep 3

# 3. Ver los zombis (aparecen como <defunct>; la 3.a columna es el PPID, el padre)
ps -ef | grep defunct

# 4. Solución de los zombis: matar al PADRE (en nuestra prueba fue el PPID 13554)
#    kill -9 <PPID>
#    ps -ef | grep defunct      -> ya no aparecen

# 5. Matar el contenedor con SIGKILL (queda en Exited (137))
podman kill --signal KILL calibre-web && podman ps -a

# 6. Reinicio automático por Restart=always del Quadlet (Up y NRestarts=1)
sleep 10 && podman ps
systemctl --user show calibre-web -p NRestarts
