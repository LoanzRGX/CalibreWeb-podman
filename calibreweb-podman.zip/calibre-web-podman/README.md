# Calibre-Web con Podman rootless en AWS EC2

Proyecto del curso **Sistemas Operativos I (2026-2)**. Calibre-Web (biblioteca de libros digitales) corre con **Podman rootless** en una instancia **EC2 AlmaLinux 9**, publicado en el puerto 80 con un subdominio de **DuckDNS**, con volúmenes persistentes, reinicio automático (Quadlet + systemd) y límites de recursos.

## Contenido

| Archivo | Qué es |
| --- | --- |
| `deploy/calibre-web.container` | **Comandos de despliegue (Quadlet).** Define el contenedor: imagen `lscr.io/linuxserver/calibre-web`, puerto 80→8083, volúmenes, límites (512 MiB, 0.8 CPU, 256 procesos) y `Restart=always`. No usamos Containerfile porque usamos la imagen oficial sin modificarla. |
| `deploy/preparar-servidor.sh` | Instala Podman y cron, permite el puerto 80 sin root (`sysctl`) y activa linger. |
| `deploy/instalar.sh` | Crea las carpetas, descarga `metadata.db`, ajusta permisos con `podman unshare` y arranca el servicio. |
| `fallas/B1_zombi_y_reinicio.sh` | Caso básico B1: procesos zombis y reinicio tras `podman kill --signal KILL`. |
| `fallas/I1_fuga_memoria_oom.sh` | Caso intermedio I1: fuga de memoria con `stress-ng` y OOM killer. |
| `fallas/A1_permisos_uid.sh` | Caso avanzado A1: permisos rotos por el mapeo de UID en rootless. |
| `scripts/backup.sh` | Backup diario de configuración y libros (conserva 7 copias). |
| `scripts/duck.sh.ejemplo` | Plantilla del script de DuckDNS (sin el token real). |

## Cómo desplegar

```bash
git clone https://github.com/USUARIO/calibre-web-podman.git
cd calibre-web-podman
bash deploy/preparar-servidor.sh
bash deploy/instalar.sh
```

Luego abrir `http://SUBDOMINIO.duckdns.org`, poner `/books` como ubicación de la base de datos y cambiar la contraseña de `admin`.

## Casos de falla

Los scripts de `fallas/` tienen los comandos en el mismo orden en que los ejecutamos, con comentarios del resultado esperado. Se recomienda ejecutarlos línea por línea para tomar las capturas del informe.

## Seguridad

- No se suben tokens ni llaves (ver `.gitignore`).
- La contraseña por defecto de `admin` se cambió en el primer ingreso.

## Uso de IA

Los scripts y la guía se prepararon con ayuda de IA (Claude) y fueron revisados y ejecutados por el equipo. Ver la bitácora de IA.
