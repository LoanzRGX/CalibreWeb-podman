#!/bin/bash
# Backup de Calibre-Web (configuración + libros). Conserva las 7 copias más recientes.
export XDG_RUNTIME_DIR=/run/user/$(id -u)
systemctl --user stop calibre-web
podman unshare tar -czpf ~/backups/calibre-$(date +%Y%m%d_%H%M).tar.gz -C ~/calibre config books
systemctl --user start calibre-web
ls -1t ~/backups/calibre-*.tar.gz | tail -n +8 | xargs -r rm --
