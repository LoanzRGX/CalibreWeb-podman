#!/bin/bash
# Preparación del servidor EC2 (AlmaLinux 9). Ejecutar una sola vez.
sudo dnf update -y && sudo dnf install -y podman cronie nano
# Permitir que un usuario normal use el puerto 80
echo "net.ipv4.ip_unprivileged_port_start=80" | sudo tee /etc/sysctl.d/99-podman-ports.conf
sudo sysctl --system
# Mantener los servicios de ec2-user aunque se cierre SSH
sudo loginctl enable-linger ec2-user
sudo systemctl enable --now crond
