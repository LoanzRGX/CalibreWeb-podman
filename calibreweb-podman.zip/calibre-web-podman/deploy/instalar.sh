#!/bin/bash
# Despliegue de Calibre-Web con Podman rootless (ejecutar como ec2-user, sin sudo)

# 1. Carpetas de datos y biblioteca inicial (metadata.db vacío del proyecto Calibre-Web)
mkdir -p ~/calibre/config ~/calibre/books ~/backups
curl -fL -o ~/calibre/books/metadata.db https://github.com/janeczku/calibre-web/raw/master/library/metadata.db

# 2. Dueño de los volúmenes = usuario 1000 DENTRO del contenedor (en el host aparece como 100999)
podman unshare chown -R 1000:1000 ~/calibre/config ~/calibre/books

# 3. Instalar el Quadlet y arrancar el servicio
mkdir -p ~/.config/containers/systemd
cp "$(dirname "$0")/calibre-web.container" ~/.config/containers/systemd/
systemctl --user daemon-reload
systemctl --user start calibre-web

# 4. Comprobar
sleep 30
systemctl --user status calibre-web --no-pager
podman ps
